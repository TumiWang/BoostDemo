//  config.hpp  ---------------------------------------------------------------//

//  Copyright 2012 Vicente J. Botet Escriba

//  Distributed under the Boost Software License, Version 1.0.
//  See http://www.boost.org/LICENSE_1_0.txt


#ifndef BOOST_RATIO_CONFIG_HPP
#define BOOST_RATIO_CONFIG_HPP

// This header is no longer useful and is only retained for compatibility

#include <cstdint>

#define BOOST_RATIO_INTMAX_C INTMAX_C

#endif  // #ifndef BOOST_RATIO_CONFIG_HPP
